import UIKit

class FirstViewController: TabVCTemplate {

    @IBOutlet weak var bookingreference: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        selectedTab = 0
        // do stuff here
    }
    
    @IBAction func toggleMenu(sender: AnyObject) {
        NSNotificationCenter.defaultCenter().postNotificationName("toggleMenu", object: nil)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if (segue.identifier == "confirm") {
            var svc = segue.destinationViewController as! GreetingsViewController;
            
            svc.bookingreference = bookingreference.text
            
        }
    }
    
}

