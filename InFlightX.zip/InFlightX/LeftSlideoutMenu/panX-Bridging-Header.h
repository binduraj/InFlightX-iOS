//
//  panX-Bridging-Header.h
//  panX
//
//  Created by Sathish Kumar Natarajan on 9/10/16.
//  Copyright © 2016 Pan Xp. All rights reserved.
//

#ifndef panX_Bridging_Header_h
#define panX_Bridging_Header_h

#import <PACCoreKit/PACCoreKit.h>
#import <PACAdvertising/PACAdvertising.h>
#import <PACPassengerdata/PACPassengerdata.h>


#endif /* panX_Bridging_Header_h */
