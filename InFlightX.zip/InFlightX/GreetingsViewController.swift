//
//  GreetingsViewController.swift
//  panX
//
//  Created by Sathish Kumar Natarajan on 9/11/16.
//  Copyright © 2016 Pan Xp. All rights reserved.
//

import UIKit

class GreetingsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var passname: UILabel!
    @IBOutlet weak var purpose: UITableView!
    var purposeofvist: [String] = ["Business", "Vacation", "Sports", "Family Reunion"]
    let textCellIdentifier = "TextCell"
    var bookingreference : String! = nil
    var passengerService : PACPassengerdataV1! = nil
    
    @IBOutlet weak var flightinfo: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        purpose.dataSource = self
        purpose.delegate = self
        
        
        PACPassengerdataV1.initServiceWithCompletionBlock {(object:AnyObject!, error) in
            if (error == nil)
            {
                self.passengerService = object as! PACPassengerdataV1
                self.getPassengerInfo()
            }
            
            
            
        }
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getPassengerInfo()
    {
        self.passengerService.requestPassengerDataWithCompletionBlock {(object:AnyObject?, error:NSError?) in
        
        if(error == nil)
        {
        // 1. pii
            let dictName: NSDictionary = object!["pii"] as! NSDictionary
        
            let firstName = dictName["first_name"] as? String
            let lastName = dictName["last_name"] as? String
            self.passname.text = "Hello" + " " + firstName! + " " + lastName!
            
            self.flightinfo.text = dictName["travel_info"] as? String
        
        // 2. demographic
        /*NSDictionary* dicDemo = (NSDictionary*)object[@"demographic"];
        
        self.lblBirthday.text       = dicDemo[@"date_of_birth"];
        self.lblGender.text         = dicDemo[@"gender"];
        self.lblNationality.text    = dicDemo[@"nationality"];
        
        // 3. contact_info
        NSDictionary* dicContact = (NSDictionary*)object[@"contact_info"];
        self.textContact.text = [dicContact description];
        
        // 4. travel_info
        NSDictionary* dicTravel = (NSDictionary*)object[@"travel_info"];
        self.textTravel.text = [dicTravel description];
        
        // 5. frequent_flyer
        NSDictionary* dicFreq = (NSDictionary*)object[@"frequent_flyer"];
        NSString* str = [dicFreq description];
        
        // 6. preferences
        NSDictionary* dicPref = (NSDictionary*)object[@"preferences"];
        str = [str stringByAppendingFormat:@"\n%@", [dicPref description]];
        
        // 7. playlists
        NSDictionary* dicPlay = (NSDictionary*)object[@"playlists"];
        str = [str stringByAppendingFormat:@"\n%@", [dicPlay description]];
        
        self.textOther.text = str;
        }
        else
        {
        NSLog(@"error: %@", [error description]);
        } */
            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.purposeofvist.count
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(textCellIdentifier, forIndexPath: indexPath)
        
        let row = indexPath.row
        cell.textLabel?.text = purposeofvist[row]
        
        return cell
    }
}
