//
//  TravelMapViewController.swift
//  panX
//
//  Created by Sathish Kumar Natarajan on 9/11/16.
//  Copyright © 2016 Pan Xp. All rights reserved.
//

import UIKit

class TravelMapViewController: UIViewController {

    @IBOutlet weak var travelmap: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
               travelmap.loadRequest(NSURLRequest(URL: NSURL(string: "hhttp://45.55.207.137:8080/inflight/viewmaps.html")!))

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
